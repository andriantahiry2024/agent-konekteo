@echo off
chcp 65001 >nul
title Konekteo - acces a distance
echo.
echo   Konekteo - installation de l'acces a distance
echo   ---------------------------------------------
echo.
set "CFG=%APPDATA%\RustDesk\config"
if not exist "%CFG%" mkdir "%CFG%"
copy /Y "%~dp0RustDesk2.toml" "%CFG%\RustDesk2.toml" >nul
echo   Configuration Konekteo appliquee.
echo   Lancement de RustDesk...
start "" "%~dp0RustDesk.exe"
echo.
echo   RustDesk va s'ouvrir. Relevez votre ID et le mot de passe
echo   affiches a gauche, puis saisissez-les sur la page Konekteo.
echo.
pause
